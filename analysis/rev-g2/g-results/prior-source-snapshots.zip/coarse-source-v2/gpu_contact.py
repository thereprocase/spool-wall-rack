"""Shared bounded normal-contact loop for GPU fixtures and actual brackets."""
import time
import numpy as np


def solve_contact(op,f,base,wall,gap0,*,maxiter=5000,max_seconds=240,
                  initial=None,preconditioner_factory=None,progress=lambda x:None,
                  save_state=lambda *x:None,max_steps=40):
    start=time.perf_counter()
    base,wall=np.unique(base).astype(int),np.asarray(wall,dtype=int)
    gap0=np.asarray(gap0,dtype=float)
    assert len(wall)==len(gap0) and len(np.unique(wall))==len(wall)
    assert np.all(gap0>=0) and not len(np.intersect1d(base,wall))
    active=np.flatnonzero(gap0<1e-12)
    history=[]
    for step in range(max_steps):
        fixed=np.union1d(base,wall[active])
        prescribed=np.zeros(op.ndof);prescribed[wall[active]]=-gap0[active]
        M,coarse_report=(None,None) if preconditioner_factory is None else preconditioner_factory(fixed)
        trace=[]
        def observe(iterations,residual,tolerance):
            entry={'stage':'cg','contact_step':step,'iterations':iterations,
                   'residual':residual,'tolerance':tolerance}
            trace.append(entry.copy());progress(entry)
        remaining=max(1.,max_seconds-(time.perf_counter()-start))
        u,r,info=op.solve(f,fixed,prescribed,maxiter,observe,remaining,initial,M)
        initial=u
        gaps=gap0+u[wall]
        info.update({'contact_step':step,'active_wall_nodes':len(active),'trace':trace,
                     'coarse_correction':coarse_report})
        history.append(info)
        save_state(step,u,r,gaps,active,fixed)
        if info['status']!='PASS_LINEAR_SOLVE':
            return u,r,gaps,active,history,info['status']
        next_active=np.flatnonzero(r[wall]-op.diag[wall]*gaps>1e-8)
        if np.array_equal(active,next_active):
            if gaps.min(initial=0)<-1e-8 or r[wall[active]].min(initial=0)<-1e-8:
                status='FAIL_CONTACT_COMPLEMENTARITY'
            else:
                status='PASS_CONTACT_NUMERICS'
            return u,r,gaps,active,history,status
        active=next_active
    return u,r,gaps,active,history,'FAIL_CONTACT_ITERATIONS'
